// ===============================
// 🔥 AUTH: REGISTRO
// ===============================
if (document.getElementById("registerBtn")) {
  document.getElementById("registerBtn").addEventListener("click", async () => {
    const username = document.getElementById("registerUsername").value;
    const email = document.getElementById("registerEmail").value;
    const password = document.getElementById("registerPassword").value;

    try {
      const userCredential = await auth.createUserWithEmailAndPassword(email, password);
      const user = userCredential.user;

      await db.collection("users").doc(user.uid).set({
        username: username,
        email: email,
        createdAt: Date.now()
      });

      alert("Cuenta creada!");
      window.location.href = "index.html";
    } catch (error) {
      alert(error.message);
    }
  });
}

// ===============================
// 🔥 AUTH: LOGIN
// ===============================
if (document.getElementById("loginBtn")) {
  document.getElementById("loginBtn").addEventListener("click", async () => {
    const email = document.getElementById("loginEmail").value;
    const password = document.getElementById("loginPassword").value;

    try {
      await auth.signInWithEmailAndPassword(email, password);
      window.location.href = "index.html";
    } catch (error) {
      alert(error.message);
    }
  });
}

// ===============================
// 🔥 AUTH: LOGOUT
// ===============================
if (document.getElementById("logoutBtn")) {
  document.getElementById("logoutBtn").addEventListener("click", async () => {
    await auth.signOut();
    window.location.href = "login.html";
  });
}

// ===============================
// 🔥 CARGAR FEED
// ===============================
async function loadFeed() {
  const container = document.getElementById("postsContainer");
  if (!container) return;

  const snapshot = await db.collection("posts").orderBy("createdAt", "desc").get();

  container.innerHTML = "";

  snapshot.forEach(doc => {
    const post = doc.data();

    const html = `
      <div class="post">
        <div class="post-header">
          <span class="post-username">${post.username}</span>
        </div>
        <img class="post-image" src="${post.imageURL}">
        <div class="post-body">
          <div class="post-likes">${post.likes} likes</div>
          <div class="post-caption">${post.caption}</div>
        </div>
      </div>
    `;

    container.innerHTML += html;
  });
}

loadFeed();

// ===============================
// 🔥 SUBIR FOTO (upload.html)
// ===============================
if (document.getElementById("uploadBtn")) {
  document.getElementById("uploadBtn").addEventListener("click", async () => {
    const file = document.getElementById("uploadFile").files[0];
    const caption = document.getElementById("uploadCaption").value;

    const user = auth.currentUser;
    if (!user) return alert("Debes iniciar sesión");

    const userDoc = await db.collection("users").doc(user.uid).get();
    const username = userDoc.data().username;

    const ref = storage.ref("posts/" + Date.now() + "_" + file.name);
    await ref.put(file);
    const imageURL = await ref.getDownloadURL();

    await db.collection("posts").add({
      username: username,
      userId: user.uid,
      caption: caption,
      imageURL: imageURL,
      likes: 0,
      createdAt: Date.now()
    });

    alert("Foto subida!");
    window.location.href = "index.html";
  });
}
