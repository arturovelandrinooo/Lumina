// 🔥 Firebase versión CDN (compatible con HTML normal)

// Configuración de tu proyecto (ya incluida)
const firebaseConfig = {
  apiKey: "AIzaSyAjUXsDj9_HxAzSf78CS334MUm9Fsfnpkw",
  authDomain: "mini-insta-dc523.firebaseapp.com",
  projectId: "mini-insta-dc523",
  storageBucket: "mini-insta-dc523.firebasestorage.app",
  messagingSenderId: "858564367818",
  appId: "1:858564367818:web:bf13d318e64a51f865eb33"
};

// Inicializar Firebase
firebase.initializeApp(firebaseConfig);

// Servicios que usaremos
const auth = firebase.auth();
const db = firebase.firestore();
const storage = firebase.storage();
