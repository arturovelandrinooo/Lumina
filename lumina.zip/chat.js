let chatName = localStorage.getItem("chatName");
let chatPhone = localStorage.getItem("chatPhone");

document.getElementById("chatName").textContent = chatName;

auth.onAuthStateChanged(user => {
  if (!user) window.location = "login.html";
  loadLastSeen();
  loadMessages(user);
  setupTyping(user);
});

function loadLastSeen() {
  db.collection("users")
    .where("username", "==", chatName)
    .onSnapshot(snap => {
      snap.forEach(doc => {
        const u = doc.data();
        if (u.lastSeen) {
          const time = new Date(u.lastSeen).toLocaleTimeString();
          document.getElementById("chatStatus").textContent = "Últ. vez: " + time;
        }
      });
    });
}

function setupTyping(user) {
  const typingRef = db.collection("typing").doc(user.uid + "_" + chatPhone);

  document.getElementById("msgInput").addEventListener("input", () => {
    typingRef.set({ typing: true });
    setTimeout(() => typingRef.set({ typing: false }), 1500);
  });

  db.collection("typing")
    .doc(chatPhone + "_" + user.uid)
    .onSnapshot(doc => {
      if (doc.exists && doc.data().typing) {
        document.getElementById("chatStatus").textContent = "escribiendo…";
      } else {
        loadLastSeen();
      }
    });
}

function loadMessages(user) {
  db.collection("messages")
    .where("between", "in", [
      user.uid + "_" + chatPhone,
      chatPhone + "_" + user.uid
    ])
    .orderBy("time")
    .onSnapshot(snap => {
      const box = document.getElementById("messages");
      box.innerHTML = "";

      snap.forEach(doc => {
        const m = doc.data();
        const cls = m.from === user.uid ? "me" : "them";
        box.innerHTML += `<div class="msg ${cls}">${m.text}</div>`;
      });

      box.scrollTop = box.scrollHeight;
    });
}

function sendMessage() {
  const text = document.getElementById("msgInput").value.trim();
  if (!text) return;

  db.collection("messages").add({
    text,
    from: auth.currentUser.uid,
    to: chatPhone,
    between: auth.currentUser.uid + "_" + chatPhone,
    time: Date.now()
  });

  document.getElementById("msgInput").value = "";
}
