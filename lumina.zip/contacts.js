auth.onAuthStateChanged(user => {
  if (!user) window.location = "login.html";
  loadContacts();
});

function addContact() {
  const name = document.getElementById("contactName").value.trim();
  const phone = document.getElementById("contactPhone").value.trim();
  const photo = document.getElementById("contactPhoto").value.trim() || "default.jpg";

  if (!name || !phone) return;

  db.collection("users")
    .doc(auth.currentUser.uid)
    .collection("contacts")
    .add({ name, phone, photo });
}

function loadContacts() {
  const list = document.getElementById("contactList");
  list.innerHTML = "";

  db.collection("users")
    .doc(auth.currentUser.uid)
    .collection("contacts")
    .onSnapshot(snap => {
      list.innerHTML = "";
      snap.forEach(doc => {
        const c = doc.data();
        list.innerHTML += `
          <div class="contact-item" onclick="openChat('${c.name}', '${c.phone}', '${c.photo}')">
            <div class="avatar" style="background-image:url('${c.photo}')"></div>
            <div>
              <strong>${c.name}</strong><br>
              <span>${c.phone}</span>
            </div>
          </div>
        `;
      });
    });
}

function openChat(name, phone, photo) {
  localStorage.setItem("chatName", name);
  localStorage.setItem("chatPhone", phone);
  localStorage.setItem("chatPhoto", photo);
  window.location = "chat.html";
}
