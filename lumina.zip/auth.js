// REGISTRO
function register() {
  const user = document.getElementById("username").value.trim();
  const pass = document.getElementById("password").value.trim();
  const photo = document.getElementById("photo").value.trim() || "default.jpg";

  if (!user || !pass) {
    alert("Rellena usuario y contraseña");
    return;
  }

  const email = user + "@lumina.app";

  auth.createUserWithEmailAndPassword(email, pass)
    .then(() => {
      const uid = auth.currentUser.uid;

      return db.collection("users").doc(uid).set({
        username: user,
        photo: photo,
        lastSeen: Date.now()
      });
    })
    .then(() => window.location = "index.html")
    .catch(err => alert(err.message));
}



// LOGIN ARREGLADO
function login() {
  const user = document.getElementById("email").value.trim();
  const pass = document.getElementById("password").value.trim();

  if (!user || !pass) {
    alert("Rellena usuario y contraseña");
    return;
  }

  const email = user + "@lumina.app";

  auth.signInWithEmailAndPassword(email, pass)
    .then(() => {
      const uid = auth.currentUser.uid;

      db.collection("users").doc(uid).get().then(doc => {
        if (!doc.exists) {
          db.collection("users").doc(uid).set({
            username: user,
            photo: "default.jpg",
            lastSeen: Date.now()
          });
        } else {
          db.collection("users").doc(uid).update({
            lastSeen: Date.now()
          });
        }
      });

      window.location = "index.html";
    })
    .catch(err => alert(err.message));
}



// LOGOUT
function logout() {
  db.collection("users").doc(auth.currentUser.uid).update({
    lastSeen: Date.now()
  }).finally(() => {
    auth.signOut().then(() => window.location = "login.html");
  });
}



// OJO PARA VER CONTRASEÑA
function togglePass() {
  const input = document.getElementById("password");
  input.type = input.type === "password" ? "text" : "password";
}
