auth.onAuthStateChanged(user => {
  if (!user) {
    window.location = "login.html";
    return;
  }

  setTimeout(() => {
    const s = document.getElementById("splash");
    if (s) s.style.display = "none";
  }, 1500);

  loadChats();
});

function loadChats() {
  const list = document.getElementById("chatList");
  list.innerHTML = "<p class='no-chats'>No tienes contactos aún. Añade uno 👥</p>";

  db.collection("users")
    .doc(auth.currentUser.uid)
    .collection("contacts")
    .onSnapshot(snap => {
      if (snap.empty) return;

      list.innerHTML = "";

      snap.forEach(doc => {
        const c = doc.data();

        list.innerHTML += `
          <div class="chat-item" onclick="openChat('${c.name}', '${c.phone}', '${c.photo || "default.jpg"}')">
            <div class="avatar" style="background-image:url('${c.photo || "default.jpg"}')"></div>
            <div>
              <strong>${c.name}</strong><br>
              <span>${c.phone}</span>
            </div>
          </div>
        `;
      });
    });
}

function openChat(name, phone, photo) {
  localStorage.setItem("chatName", name);
  localStorage.setItem("chatPhone", phone);
  localStorage.setItem("chatPhoto", photo);

  window.location = "chat.html";
}
