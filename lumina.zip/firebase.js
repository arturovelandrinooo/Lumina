const firebaseConfig = {
  apiKey: "AIzaSyBkHTltcTTPEQ239_vj3IQUtllVSUTX9f0",
  authDomain: "luminachat-b92ec.firebaseapp.com",
  projectId: "luminachat-b92ec",
  storageBucket: "luminachat-b92ec.firebasestorage.app",
  messagingSenderId: "412727199556",
  appId: "1:412727199556:web:758a2cf85f866451ef3911"
};

firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const db = firebase.firestore();
